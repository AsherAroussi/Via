import json
import unittest

from docker.directGraphFunctions import DirectGraphFunctions
from docker.multiDirectGraphFunctions import MultiDirectGraphFunctions
from docker.multiUnDirectGraphFunctions import MultiUnDirectGraphFunctions
from docker.unDirectGraphFunctions import UnDirectGraphFunctions
from docker.utils import GraphTypes

graph = ()


def create_graph_from_file(file_path):
    try:
        with open(file_path) as f:
            json_data = json.loads(f.read())

        is_direct = json_data['directed']
        is_multi = json_data['multigraph']

        if is_multi:
            if is_direct:
                print("Creating Multi-Directed graph")
                return MultiDirectGraphFunctions(json_data)
            else:
                print("Creating Multi-UnDirected graph")
                return MultiUnDirectGraphFunctions(json_data)
        else:  # Not Multi
            if is_direct:
                print("Creating Directed graph")
                return DirectGraphFunctions(json_data)
            else:
                print("Creating UnDirected graph")
                return UnDirectGraphFunctions(json_data)
    except Exception as e:
        print("Failed to load file ", file_path, ": " + e.__str__())
        return False


class MyTestCase(unittest.TestCase):
    def test_create_graph(self):
        self.assertTrue(create_graph_from_file("../conf/unittest-graph.json"))
        self.assertFalse(create_graph_from_file("non_exists.json"))
        self.assertFalse(create_graph_from_file("bad_format_unittest_graph.json"))

    def test_shortest_path(self):
        global graph
        graph = create_graph_from_file("../conf/unittest-graph.json")

        # Success case
        path, result = graph.get_shortest_path("A", "D")
        self.assertEqual(path, ["A", "C", "D"])
        self.assertEqual(result, 200)

        # Fail case
        path, result = graph.get_shortest_path("A", "E")
        self.assertEqual(result, 400)

        path, result = graph.get_shortest_path("A", "")
        self.assertEqual(result, 400)

    def test_update_weight(self):
        global graph
        graph = create_graph_from_file("../conf/unittest-graph.json")


        # Success case
        w, result = graph.get_weight("A", "C")
        self.assertEqual(w, 1)
        self.assertEqual(result, 200)
        line, result = graph.update_weight("A", "C", "10")
        self.assertEqual(result, 200)
        w, result = graph.get_weight("A", "C")
        self.assertEqual(w, 10)
        self.assertEqual(result, 200)

        # Fail case
        w, result = graph.update_weight("A", "D", "100")
        self.assertEqual(result, 400)

        w, result = graph.update_weight("", "D", "33")
        self.assertEqual(result, 400)

        w, result = graph.update_weight("", "D", "-37")
        self.assertEqual(result, 400)

    def test_functions(self):
        global graph

        graph = create_graph_from_file("../conf/unittest-graph.json")
        path, result = graph.get_shortest_path("A", "C")
        self.assertEqual(path, ["A", "C"])
        self.assertEqual(result, 200)

        line, result = graph.update_weight("A", "C", "100")
        self.assertEqual(result, 200)

        w, result = graph.get_weight("A", "C")
        self.assertEqual(w, 100)
        self.assertEqual(result, 200)

        path, result = graph.get_shortest_path("A", "C")
        if graph.get_type() is GraphTypes.multiundirect or graph.get_type() is GraphTypes.multidirect:
            self.assertEqual(path, ["A", "C"])
        else:
            self.assertEqual(path, ["A", "B", "C"])
        self.assertEqual(result, 200)


if __name__ == '__main__':
    unittest.main()
