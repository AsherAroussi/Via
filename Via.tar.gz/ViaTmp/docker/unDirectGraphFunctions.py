import networkx as nx

from regularGraphFunctionsBase import RegularGraphFunctionsBase
from utils import GraphTypes


class UnDirectGraphFunctions(RegularGraphFunctionsBase):
    def __init__(self, file):
        super(UnDirectGraphFunctions, self).__init__(GraphTypes.undirect)
        self._graph = nx.Graph(name=file['graph']['name'], version=file['graph']['version'])
        super().build_graph_from_file(file)
