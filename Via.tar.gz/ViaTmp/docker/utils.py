import enum


def is_valid_input(param):
    if not param or len(param) == 0:
        return False
    return True


def convert_to_int(param):
    return int(param)


def validate_short_path_variables(source, target):
    try:
        if not is_valid_input(source) or\
           not is_valid_input(target):
            return False
    except Exception as e:
        print("Failed to validate_short_path_variables: " + e.__str__())
        return False
    return True


def validate_update_weight_variables(source, target, weight):
    try:
        if not is_valid_input(source) or \
           not is_valid_input(target) or \
           not isinstance(convert_to_int(weight), int) or \
           convert_to_int(weight) < 0:
            return False
    except Exception as e:
        print("Failed to validate_update_weight_variables: " + e.__str__())
        return False
    return True


class GraphTypes(enum.Enum):
    direct = 1
    undirect = 2
    multidirect = 3
    multiundirect = 4
