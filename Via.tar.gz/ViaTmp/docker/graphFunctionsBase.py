from multiprocessing import RLock


class GraphFunctionsBase:
    _graph = {}
    _mutex = RLock()
    _type = 0

    def __init__(self, g_type):
        self._type = g_type

    def get_type(self):
        return self._type

    def build_graph_from_file(self, json_data):
        try:
            for elem in json_data['nodes']:
                node_id = elem['id']
                #print("node_id ", node_id)
                self._graph.add_node(node_id)
            for elem in json_data['links']:
                src = elem['source']
                dst = elem['target']
                w = elem['attributes']['weight']
                #print(src, " to ", dst, " costs ", w)
                self._graph.add_edge(src, dst, weight=w)
            return True
        except Exception as e:
            print("Failed to build graph: " + e.__str__())
        return False
