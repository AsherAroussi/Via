import json
import os

from directGraphFunctions import DirectGraphFunctions
from multiDirectGraphFunctions import MultiDirectGraphFunctions
from multiUnDirectGraphFunctions import MultiUnDirectGraphFunctions
from unDirectGraphFunctions import UnDirectGraphFunctions

from flask import Flask, request

app = Flask(__name__)
graph = ()


@app.route("/api/v1/short_path", methods=["GET"])
def get_shortest_path():
    global graph

    try:
        source = request.args.get('source')
        target = request.args.get('target')

        path, result = graph.get_shortest_path(source, target)
        return json.dumps(path, indent=4), result

    except Exception as e:
        print("Failed to get short_path: " + e.__str__())


@app.route("/api/v1/update_weight", methods=["GET"])
def update_weight():
    global graph

    try:
        source = request.args.get('source')
        target = request.args.get('target')
        weight = request.args.get('weight')
        line, result = graph.update_weight(source, target, weight)
        return line, result

    except Exception as e:
        print("Failed to update_weight: " + e.__str__())


def create_graph_from_file(file_path):
    try:
        print("pwd:", os.getcwd())
        with open(file_path) as f:
            json_data = json.loads(f.read())

        is_direct = json_data['directed']
        is_multi = json_data['multigraph']

        if is_multi:
            if is_direct:
                print("Creating Multi-Directed graph")
                return MultiDirectGraphFunctions(json_data)
            else:
                print("Creating Multi-UnDirected graph")
                return MultiUnDirectGraphFunctions(json_data)
        else:  # Not Multi
            if is_direct:
                print("Creating Directed graph")
                return DirectGraphFunctions(json_data)
            else:
                print("Creating UnDirected graph")
                return UnDirectGraphFunctions(json_data)
    except Exception as e:
        print("Failed to load file ", file_path, ": " + e.__str__())
        return False


def run(listen_port):
    app.run("0.0.0.0", listen_port)


if __name__ == '__main__':
    try:
        port = os.environ['FLASK_PORT']
    except Exception as e:
        port = 8000

    conf_file = "conf/test-graph.json"
    #conf_file = "conf/unittest-graph.json"
    graph = create_graph_from_file(conf_file)
    if graph is False:
        exit(-1)
    run(port)
