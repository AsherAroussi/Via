import networkx as nx

from regularGraphFunctionsBase import RegularGraphFunctionsBase
from utils import GraphTypes


class DirectGraphFunctions(RegularGraphFunctionsBase):
    def __init__(self, file):
        super(DirectGraphFunctions, self).__init__(GraphTypes.direct)
        self._graph = nx.DiGraph(name=file['graph']['name'], version=file['graph']['version'])
        super().build_graph_from_file(file)
