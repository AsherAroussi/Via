import networkx as nx

from graphFunctionsBase import GraphFunctionsBase
from utils import validate_short_path_variables, validate_update_weight_variables, convert_to_int


class RegularGraphFunctionsBase(GraphFunctionsBase):

    def __init__(self, g_type):
        super(RegularGraphFunctionsBase, self).__init__(g_type)

    def get_shortest_path(self, source, target):
        if not validate_short_path_variables(source, target):
            return "shortest_path request MUST have source and target info. Missing parameter", 400

        with self._mutex:
            try:
                if nx.has_path(self._graph, source, target):
                    return nx.dijkstra_path(self._graph, source, target), 200
                else:
                    return "No such path between " + source + " and " + target, 400
            except Exception as e:
                return "Failed to find shortest path graph: " + e.__str__(), 500

    def update_weight(self, source, target, new_weight):
        if not validate_update_weight_variables(source, target, new_weight):
            return "update_weight request MUST have source, target and weight(positive) info. Missing parameter", 400

        with self._mutex:
            try:
                list_neighbors = self._graph.neighbors(source)
                if target in list_neighbors:
                    self._graph[source][target]['weight'] = convert_to_int(new_weight)
                    return "Weight is updated", 200
                else:
                    return source + " and  " + target + " are not neighbors", 400
            except Exception as e:
                return "Failed to update weight: " + e.__str__(), 500

    def get_weight(self, source, target):
        with self._mutex:
            try:
                list_neighbors = self._graph.neighbors(source)
                if target in list_neighbors:
                    return self._graph[source][target]['weight'], 200
                else:
                    return source + " and  " + target + " are not neighbors", 400
            except Exception as e:
                return "Failed to get weight: " + e.__str__(), 500