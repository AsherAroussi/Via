import networkx as nx

from multiGraphFunctionsBase import MultiGraphFunctionsBase
from utils import GraphTypes


class MultiUnDirectGraphFunctions(MultiGraphFunctionsBase):
    def __init__(self, file):
        super(MultiUnDirectGraphFunctions, self).__init__(GraphTypes.multiundirect)
        self._graph = nx.MultiGraph(name=file['graph']['name'], version=file['graph']['version'])
        super().build_graph_from_file(file)
