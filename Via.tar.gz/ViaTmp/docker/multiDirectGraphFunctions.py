import networkx as nx

from multiGraphFunctionsBase import MultiGraphFunctionsBase
from utils import GraphTypes


class MultiDirectGraphFunctions(MultiGraphFunctionsBase):
    def __init__(self, file):
        super(MultiDirectGraphFunctions, self).__init__(GraphTypes.multidirect)
        self._graph = nx.MultiDiGraph(name=file['graph']['name'], version=file['graph']['version'])
        super().build_graph_from_file(file)
